## Rufous the Quadcopter

Hi proffessor,

hope you find this, or that could be bad.

Anyways, The project final results are in rufous.mlx. My attempt at a Lyapunov Stability proof is in 'rufous_nonlinear_analysis.mlx'. The rest (sorry about so many files) are functions and images used in various places. The python sim is cool but I figured you didn't care about it so I didn't attach (also requires a ROS setup and needs an Ubuntu machine).

In terms of controller synthesis I am pretty happy, this has been my most successful attempt at a Quad controller so...

The analysis is suspicious, but only because I feel unverified. The dynamics and controls work in sim (Elon would classify this as an absolute success).
